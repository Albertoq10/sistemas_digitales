/*
 * servomotores_pwm.h
 *
 *  Created on: Jan 18, 2026
 *      Author: alber
 */

#ifndef APPLICATION_SERVOMOTORES_PWM_H_
#define APPLICATION_SERVOMOTORES_PWM_H_

#include "main.h"

#define ARD_D4_Pin GPIO_PIN_3
#define ARD_D4_GPIO_Port GPIOA


extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

void persiana_set_pct(uint8_t persiana, uint8_t pct);


void MX_TIM2_Init(void);
void MX_TIM3_Init(void);





#endif /* APPLICATION_SERVOMOTORES_PWM_H_ */
