#ifndef OLED_STATUS_H
#define OLED_STATUS_H

#include <stdint.h>
#include "proyecto_persianas.h"
#include "stm32l4xx_hal.h"

void OLED_StatusUpdate(I2C_HandleTypeDef *hi2c1, uint8_t temp, modos_persianas_t modo, uint8_t p1, uint8_t p2);

#endif
