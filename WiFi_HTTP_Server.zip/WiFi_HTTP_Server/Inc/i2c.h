/*
 * i2c.h
 *
 *  Created on: Jan 13, 2026
 *      Author: alber
 */

#ifndef APPLICATION_USER_I2C_H_
#define APPLICATION_USER_I2C_H_

#include "main.h"

#define ARD_D15_Pin GPIO_PIN_8
#define ARD_D15_GPIO_Port GPIOB
#define ARD_D14_Pin GPIO_PIN_9
#define ARD_D14_GPIO_Port GPIOB

extern I2C_HandleTypeDef hi2c1;

void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c);
void MX_I2C1_Init(void);



#endif /* APPLICATION_USER_I2C_H_ */
