/*
 * ldr_adc.h
 *
 *  Created on: Jan 16, 2026
 *      Author: alber
 */

#ifndef APPLICATION_USER_LDR_ADC_H_
#define APPLICATION_USER_LDR_ADC_H_
#include "main.h"


#define ARD_A1_Pin GPIO_PIN_4
#define ARD_D6_GPIO_Port GPIOB
#define ARD_D6_Pin GPIO_PIN_1
#define ARD_D7_GPIO_Port GPIOA
#define ARD_D7_Pin GPIO_PIN_4

extern ADC_HandleTypeDef hadc1;

void MX_ADC1_Init(void);

void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc);
uint8_t leer_nivel_luz(ADC_HandleTypeDef *hadc1);//


#endif /* APPLICATION_USER_LDR_ADC_H_ */
